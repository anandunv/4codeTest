﻿using ReportEngine;
using System;

namespace XMLReportEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            GenerateReport();
        }

        private static void GenerateReport()
        {
            var configLocation = @"D:\XMlReport\NewConfig.xml";
            var templateLocation = @"D:\XMlReport\Tempalte.xlsx";
            var reportLocation = @"D:\XMlReport\Reports\";

            IXMLReportEngine reportEngine = new ExcelReportEngine();

            reportEngine.LoadComponentConfig(configLocation);

            reportEngine.CreateReportBase("", "");
        }
    }
}
