﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using DocumentFormat.OpenXml.Packaging;
using ReportEngine.Elements;
using ReportEngine.Helper;

namespace ReportEngine
{
    public class ExcelReportEngine : IXMLReportEngine
    {
        private List<ReportSheet> templateSheets;
        XMLHelper xmlHelper;

        public bool LoadComponentConfig(string xmlLocation)
        {
            try
            {
                XmlDocument reportConfig = new XmlDocument();
                reportConfig.Load(xmlLocation);

                xmlHelper = new XMLHelper(reportConfig);

                templateSheets = xmlHelper.FetchSheets();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public bool CreateReportBase(string templateLocation, string temprorySaveLocation)
        {
            object reportWBPart = null;
            LoadComponentsForSheet(reportWBPart);

            return false;
        }

        private void LoadComponentsForSheet(object reportWBPart)
        {
            foreach (var templateSheet in templateSheets)
            {
                object referSheet = null;
                object newSheet = null;

                var sheetName = templateSheet.name;
                var sections = xmlHelper.FetchSections(sheetName);

                foreach (var section in sections)
                {
                    if (typeof(HeadSection) == section.GetType())
                    {
                        var head = (HeadSection)section;
                        var headComponents = xmlHelper.FetchHeaderComponents(sheetName);
                        head.SetChild(headComponents);

                    }
                    else if (typeof(BodySection) == section.GetType())
                    {
                        var body = (BodySection)section;
                        var bodyComponents = xmlHelper.FetchBodyComponents(sheetName);
                        body.SetChild(bodyComponents);
                    }

                    WriteSection(section,referSheet,newSheet);
                }
            }
        }

        private void WriteSection(ISection section,object referSheet,object newSheet)
        {
            List<BaseComponent> prevComponents = new List<BaseComponent>();

            var components = section.GetAllChild().OrderBy(x => x.RowIndex);
            foreach (var child in components)
            {
                var currentComponent = child.Write(referSheet,newSheet,null,prevComponents);
                prevComponents.Add(currentComponent);
            }
        }
    }
}
