﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using ReportEngine.Elements;
using ReportEngine.Elements.Components;
using ReportEngine.Elements.Enums;

namespace ReportEngine.Helper
{
    public class XMLHelper
    {
        private readonly XmlDocument configFile;

        public XMLHelper(XmlDocument configFile)
        {
            this.configFile = configFile;
        }

        internal List<ReportSheet> FetchSheets()
        {
            var sheetComponents = new List<ReportSheet>();

            XmlNodeList sheetNodes = configFile.SelectNodes(@"//Report/Sheet");

            foreach (XmlNode node in sheetNodes)
            {
                var sheetName = node.Attributes["name"]?.Value?.ToString();

                sheetComponents.Add(new ReportSheet(sheetName));
            }

            return sheetComponents;
        }

        internal List<ISection> FetchSections(string sheetName)
        {
            List<ISection> sections = new List<ISection>();
            XmlNode sheet = configFile.SelectSingleNode($"//Report/Sheet[@name='{sheetName}']");

            foreach (XmlNode node in sheet.ChildNodes)
            {
                var isSection = Enum.TryParse(node.Name.ToUpper(), out SectionType component);

                if (isSection)
                {
                    switch (component)
                    {
                        case SectionType.HEAD:
                            sections.Add(new HeadSection() { });
                            break;
                        case SectionType.BODY:
                            sections.Add(new BodySection() { });
                            break;
                        default: break;
                    }
                }
            }

            return sections;
        }

        internal List<BaseComponent> FetchHeaderComponents(string sheetName)
        {
            List<BaseComponent> childComponents = new List<BaseComponent>();
            XmlNode header = configFile.SelectSingleNode($"//Report/Sheet[@name='{sheetName}']/Head");

            foreach (XmlNode node in header.ChildNodes)
            {
                var isComponent = Enum.TryParse(node.Name.ToUpper(), out ComponentType component);

                if (isComponent)
                {
                    var id = node.Attributes["id"]?.Value;
                    var rowIndex = node.Attributes["rowIndex"]?.Value;
                    switch (component)
                    {
                        case ComponentType.STYLE:
                            childComponents.Add(new StyleComponent(id, rowIndex) { });
                            break;
                        default: break;
                    }
                }
            }

            return childComponents;
        }

        internal List<BaseComponent> FetchBodyComponents(string sheetName)
        {
            List<BaseComponent> childComponents = new List<BaseComponent>();
            XmlNode header = configFile.SelectSingleNode($"//Report/Sheet[@name='{sheetName}']/Body");

            foreach (XmlNode node in header.ChildNodes)
            {
                var isComponent = Enum.TryParse(node.Name.ToUpper(), out ComponentType component);

                if (isComponent)
                {
                    var id = node.Attributes["id"]?.Value;
                    var rowIndex = node.Attributes["rowIndex"]?.Value;
                    switch (component)
                    {
                        case ComponentType.HEADING:
                            childComponents.Add(new HeadingComponent(id, rowIndex) { });
                            break;
                        default: break;
                    }
                }
            }

            return childComponents;
        }
    }
}
