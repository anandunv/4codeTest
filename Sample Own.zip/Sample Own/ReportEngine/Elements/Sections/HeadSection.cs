﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReportEngine.Elements
{
    public class HeadSection : ISection
    {
        private IList<BaseComponent> childComponents;

        public HeadSection()
        {
            childComponents = new List<BaseComponent>();
        }

        public void SetChild(List<BaseComponent> components)
        {
            childComponents = components;
        }

        public IList<BaseComponent> GetAllChild()
        {
            return childComponents;
        }

        public BaseComponent GetChild(string id)
        {
            return childComponents.First(x => x.Id == id);
        }

        public IList<BaseComponent> GetChildComponentsInRow(string rowIndex)
        {
            return childComponents.Where(x => x.RowIndex == rowIndex).ToList();
        }
    }
}
