﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements
{
    public class BodySection : ISection
    {
        public void SetChild(List<BaseComponent> components)
        {
            throw new NotImplementedException();
        }

        public BaseComponent GetChild(string id)
        {
            throw new NotImplementedException();
        }

        public IList<BaseComponent> GetChildComponentsInRow(string rowIndex)
        {
            throw new NotImplementedException();
        }

        public IList<BaseComponent> GetAllChild()
        {
            throw new NotImplementedException();
        }
    }
}
