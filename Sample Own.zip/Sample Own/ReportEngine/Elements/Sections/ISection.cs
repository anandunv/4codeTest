﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements
{
    public interface ISection
    {
        void SetChild(List<BaseComponent> components);

        IList<BaseComponent> GetAllChild();

        BaseComponent GetChild(string id);

        IList<BaseComponent> GetChildComponentsInRow(string rowIndex);
    }
}
