﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements
{
    public abstract class BaseComponent
    {
        public string Id { get;}
        public string RowIndex { get;}

        public string ColStart { get; set; }

        public string RowEnd { get; set; }

        public string ColEnd { get; set; }

        public BaseComponent(string Id,string rowIndex)
        {
            this.Id = Id;
            this.RowIndex = rowIndex;
        }

        public abstract void Read();

        public abstract BaseComponent Write(object referSheet,object newSheet,object data, List<BaseComponent> prevComponents);
    }
}
