﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements.Components
{
    public class StyleComponent : BaseComponent
    {
        public StyleComponent(string Id, string rowIndex) : base(Id, rowIndex)
        {
        }

        public override void Read()
        {
            //throw new NotImplementedException();
        }

        public override BaseComponent Write(object referSheet, object newSheet, object data, List<BaseComponent> prevComponents)
        {
            return this;
        }
    }
}
