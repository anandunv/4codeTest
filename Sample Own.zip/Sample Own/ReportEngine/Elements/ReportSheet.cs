﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements
{
    public class ReportSheet
    {
        public readonly string  name;

        public ReportSheet(string name)
        {
            this.name = name;
        }
    }
}
