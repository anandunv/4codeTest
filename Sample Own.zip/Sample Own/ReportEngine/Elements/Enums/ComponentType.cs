﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements.Enums
{
    public enum ComponentType
    {
        STYLE = 1,
        HEADING = 2
    }
}
