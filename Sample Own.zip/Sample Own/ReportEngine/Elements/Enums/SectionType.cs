﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportEngine.Elements.Enums
{
    public enum SectionType
    {
        HEAD = 1,
        BODY = 2
    }
}
