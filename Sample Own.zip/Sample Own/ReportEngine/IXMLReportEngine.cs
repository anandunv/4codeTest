﻿using System;

namespace ReportEngine
{
    public interface IXMLReportEngine
    {
        bool LoadComponentConfig(string xmlLocation);

        bool CreateReportBase(string templateLocation,string temprorySaveLocation);
    }
}
